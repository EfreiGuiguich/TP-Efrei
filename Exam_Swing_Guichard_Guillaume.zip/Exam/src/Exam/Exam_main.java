package Exam;

import javax.swing.SwingUtilities;

public class Exam_main 
{
    public static void main(String[] args) 
    {
        Converteur fenetre = new Converteur("Convert Celsius to Fahrenheit");
    }
}
